import { defineStore } from 'pinia'

export const useCartStore = defineStore('cart', {
  state: () => ({
    cartItems: JSON.parse(localStorage.getItem('cart')) || [],
    goodsList: [
      { id: 1, name: 'Vue实战教程', price: 89, img: 'https://picsum.photos/200/200?1' },
      { id: 2, name:  '前端工程化手册', price: 129, img: 'https://picsum.photos/200/200?2' },
      { id: 3, name: 'CSS进阶指南', price: 69, img: 'https://picsum.photos/200/200?3' }
    ]
  }),
  getters: {
    totalPrice: (state) => {
      return state.cartItems.filter(item => item.checked).reduce((sum, item) => sum + item.price * item.quantity, 0)
    },
    totalQuantity: (state) => {
      return state.cartItems.reduce((sum, item) => sum + item.quantity, 0)
    },
    isAllChecked: (state) => {
      return state.cartItems.length > 0 && state.cartItems.every(item => item.checked)
    }
  },
  actions: {
    addToCart(goods) {
      const existingItem = this.cartItems.find(item => item.id === goods.id)
      if (existingItem) {
        existingItem.quantity++
      } else {
        this.cartItems.push({ ...goods, quantity: 1, checked: true })
      }
    },
    updateQuantity(id, type) {
      const item = this.cartItems.find(item => item.id === id)
      if (type === 'add') item.quantity++
      else {
        item.quantity--
        if (item.quantity <= 0) this.removeFromCart(id)
      }
    },
    removeFromCart(id) {
      this.cartItems = this.cartItems.filter(item => item.id !== id)
    },
    toggleCheck(id) {
      const item = this.cartItems.find(item => item.id === id)
      item.checked = !item.checked
    },
    toggleAllCheck(checked) {
      this.cartItems.forEach(item => item.checked = checked)
    }
  },
  watch: {
    cartItems: {
      deep: true,
      handler(val) {
        localStorage.setItem('cart', JSON.stringify(val))
      }
    }
  }
})