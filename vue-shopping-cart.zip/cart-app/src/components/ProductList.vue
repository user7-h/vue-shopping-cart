<template>
  <div class="product-list">
    <h2>商品列表</h2>
    <div class="product-items">
      <div class="product-item" v-for="goods in goodsList" :key="goods.id">
        <img :src="goods.img" alt="商品图片" class="product-img">
        <div class="product-info">
          <h3>{{ goods.name }}</h3>
          <p class="price">¥{{ goods.price }}</p >
          <button @click="addToCart(goods)" class="add-btn">加入购物车</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useCartStore } from '@/stores/cartStore'
const cartStore = useCartStore()
const { goodsList, addToCart } = cartStore
</script>

<style scoped>
.product-list { margin: 20px; }
.product-items { display: flex; gap: 20px; flex-wrap: wrap; }
.product-item { width: 200px; border: 1px solid #eee; padding: 10px; border-radius: 8px; }
.product-img { width: 100%; height: 150px; object-fit: cover; border-radius: 4px; }
.price { color: #f40; font-weight: bold; }
.add-btn { background: #f40; color: #fff; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; }
.add-btn:hover { opacity: 0.9; }
</style>