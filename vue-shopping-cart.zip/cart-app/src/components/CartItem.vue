<template>
  <div class="cart-item" v-if="item">
    <input type="checkbox" v-model="item.checked" @change="toggleCheck(item.id)">
    <img :src="item.img" alt="商品图片" class="item-img">
    <div class="item-info">
      <h4>{{ item.name }}</h4>
      <p class="item-price">¥{{ item.price }}</p >
    </div>
    <div class="quantity-control">
      <button @click="updateQuantity(item.id, 'sub')" :disabled="item.quantity <= 1">-</button>
      <span>{{ item.quantity }}</span>
      <button @click="updateQuantity(item.id, 'add')">+</button>
    </div>
    <div class="item-total">¥{{ item.price * item.quantity }}</div>
    <button @click="removeFromCart(item.id)" class="remove-btn">删除</button>
  </div>
</template>

<script setup>
import { defineProps } from 'vue'
import { useCartStore } from '@/stores/cartStore'

const cartStore = useCartStore()
const props = defineProps({
  item: { type: Object, required: true }
})

const { updateQuantity, removeFromCart, toggleCheck } = cartStore
</script>

<style scoped>
.cart-item { display: flex; align-items: center; gap: 15px; padding: 10px; border-bottom: 1px solid #eee; }
.item-img { width: 80px; height: 80px; object-fit: cover; border-radius: 4px; }
.quantity-control { display: flex; align-items: center; gap: 8px; }
.quantity-control button { width: 30px; height: 30px; border: 1px solid #eee; background: #fff; cursor: pointer; }
.quantity-control button:disabled { opacity: 0.5; cursor: not-allowed; }
.item-total { color: #f40; font-weight: bold; }
.remove-btn { color: #666; border: none; background: transparent; cursor: pointer; }
.remove-btn:hover { color: #f40; }
</style>