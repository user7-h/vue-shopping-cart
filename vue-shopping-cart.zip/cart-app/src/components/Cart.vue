<template>
  <div class="cart-container">
    <h2>我的购物车</h2>
    <div v-if="cartItems.length === 0" class="empty-cart">购物车为空，快去添加商品吧～</div>
    <div v-else>
      <div class="cart-header">
        <input type="checkbox" v-model="isAllChecked" @change="toggleAllCheck(isAllChecked)">
        <span>全选</span>
        <span class="header-total">合计：¥{{ totalPrice }}</span>
      </div>
      <div class="cart-list">
        <CartItem v-for="item in cartItems" :key="item.id" :item="item" />
      </div>
      <div class="cart-footer">
        <p>商品总数：{{ totalQuantity }} 件 | 已选商品总价：¥{{ totalPrice }}</p >
      </div>
    </div>
  </div>
</template>

<script setup>
import CartItem from './CartItem.vue'
import { useCartStore } from '@/stores/cartStore'

const cartStore = useCartStore()
const { cartItems, totalPrice, totalQuantity, isAllChecked, toggleAllCheck } = cartStore
</script>

<style scoped>
.cart-container { margin: 20px; padding: 20px; border: 1px solid #eee; border-radius: 8px; }
.empty-cart { text-align: center; padding: 50px; color: #999; }
.cart-header { display: flex; align-items: center; gap: 10px; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 1px solid #eee; }
.header-total { margin-left: auto; color: #f40; font-size: 18px; font-weight: bold; }
.cart-footer { margin-top: 15px; padding-top: 10px; border-top: 1px solid #eee; text-align: right; }
</style>