<template>
  <div id="app">
    <ProductList />
    <Cart />
  </div>
</template>

<script setup>
import ProductList from './components/ProductList.vue'
import Cart from './components/Cart.vue'
</script>

<style scoped>
#app { max-width: 1200px; margin: 0 auto; padding: 20px; }
</style>
